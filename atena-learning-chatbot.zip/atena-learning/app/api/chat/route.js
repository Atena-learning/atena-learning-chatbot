import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function buildSystem(level) {
  const lvMap = {
    beginner:
      "A1–A2: use very simple words and short sentences. Focus only on the most critical error.",
    intermediate:
      "B1–B2: conversational English, grammar errors expected. Correct up to 2 errors.",
    advanced:
      "C1–C2: near-native. Focus on nuance, idioms, style. Correct subtle mistakes.",
  };
  return `You are an enthusiastic, warm English tutor for Atena Learning English School. Student level: ${lvMap[level] || lvMap["intermediate"]}

YOUR TASKS:
1. CHAT naturally — ask follow-up questions, share opinions, keep the conversation going.
2. CORRECT errors — if there are mistakes, add this block AFTER your reply:
[CORRECTIONS]
WRONG: "original text" | RIGHT: "corrected version" | WHY: brief reason
[/CORRECTIONS]
Only the most important errors. Never more than 2 corrections per message.
3. SUGGEST better expressions naturally inside your reply ("You could also say…").
4. ENCOURAGE genuinely — celebrate good vocabulary, good grammar, interesting ideas.
5. AWARD POINTS — if the student used great English, add [POINTS:X] (1–5) at the very end.

TONE: Warm, fun, patient — like a native-speaking friend who teaches. Always end with an engaging question.`;
}

export async function POST(req) {
  try {
    const { messages, level } = await req.json();
    if (!messages || !Array.isArray(messages)) {
      return Response.json({ error: "Invalid messages" }, { status: 400 });
    }
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: buildSystem(level || "intermediate"),
      messages,
    });
    const text = (response.content || []).map((b) => b.text || "").join("");
    return Response.json({ text });
  } catch (err) {
    console.error(err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
